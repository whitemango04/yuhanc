#include <stdio.h>

int main()
{
	printf("1학년: 시험문제가 어렵나요?\n");
	printf("선배: 아니\n\n");
	printf("1학년: 전 어렵던데... 제가 멍청한가봐요ㅠㅠ\n");
	printf("선배: 난 이 수업이 5번째다... 음하하하하하...\n\n")

	printf("하지만 1학년이 시험을 더 잘봤다고 한다....\n");
		
	return 0;
}