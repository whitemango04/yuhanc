#include "GameUtil.h"
#include <stdio.h>

void print_your_id(int id)
{
	printf();	
}