#include "GameUtil.h"

int main()
{
	print_your_id(20030203);
	return 0;
}
